package com.sreejan.controller;

import com.sreejan.com.teena.model.*;
import com.sreejan.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.stream.Collectors;

@RestController
@EnableAutoConfiguration
public class CustomerController {
    CustomerService service;

    @Autowired
    public void setCustomerService(CustomerService service) {
        this.service = service;
    }

    @GetMapping(value ="/api/customer/{orgNum}",produces = "application/json")
    public CustomerResponse getCustomers(@PathVariable String orgNum) {
        boolean isOrgNumInvalid = false;
        CustomerResponse response = new CustomerResponse();
        int oNum = 0;
        try {
            oNum = Integer.parseInt(orgNum);
        }catch (NumberFormatException e){
            isOrgNumInvalid = true;
        }

        if(isOrgNumInvalid){
            response.setResponseType("ERROR");
            response.setMsg("Invalid Organisation number!");
            return response;
        }

        Customer customer = service.getCustomer(oNum);
        if(customer==null){
            response.setResponseType("WARNING");
            response.setMsg("No Customer Found!");
            return response;
        }

        response.setResponseType("SUCCESS");
        response.setMsg("Customer Data");
        response.setCustomer(customer);
        return response;
    }

    @PostMapping("/api/customer")
    public ResponseEntity<?> saveCustomer(@Valid @RequestBody Customer customer, Errors errors) {

        CustomerResponse response = new CustomerResponse();
        if (errors.hasErrors()) {
            response.setResponseType("ERROR");
            response.setMsg(errors.getAllErrors()
                    .stream().map(error -> error.getDefaultMessage())
                    .collect(Collectors.joining(". ")));
            return ResponseEntity.badRequest().body(response);
        }
        if(service.isOrgNumPresent(customer.getOrgNum())){
            response.setResponseType("ERROR");
            response.setMsg("Customer with same Org Number already present!");
            return ResponseEntity.ok(response);
        }

        service.saveCustomer(customer);
        response.setResponseType("SUCCESS");
        response.setMsg("Customer Saved Successfully!");
        return ResponseEntity.ok(response);

    }

}
