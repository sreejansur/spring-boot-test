package com.sreejan.com.teena.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer {
    @Id
    @Column(name="org_num")
    private int orgNum;

    @Column(name="cust_name")
    private String custName;

    public Customer(){}

    public Customer(String custName, int orgNum){
        this.custName = custName;
        this.orgNum = orgNum;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public int getOrgNum() {
        return orgNum;
    }

    public void setOrgNum(int orgNum) {
        this.orgNum = orgNum;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "custName='" + custName + '\'' +
                ", orgNum=" + orgNum +
                '}';
    }
}
