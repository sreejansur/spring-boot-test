package com.sreejan.services;

import com.sreejan.com.teena.model.Customer;
import com.sreejan.dao.CustomerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;

@Transactional
@Service
public class CustomerService {
    //List<Customer> custList = new ArrayList<>();
    @Autowired
    private CustomerDao customerDao;

    public Customer getCustomer(int orgNum){
        /*Customer customer = custList.stream()
                .filter(cust -> cust.getOrgNum() == orgNum).findFirst().orElse(null);*/
        Customer customer = customerDao.getCustomerByOrgNum(orgNum);
        return customer;
    }

    public boolean isOrgNumPresent(int orgNum){
        return getCustomer(orgNum)!=null;
    }

    public void saveCustomer(Customer customer){
        //custList.add(customer);
        customerDao.addCustomer(customer);
    }


}
