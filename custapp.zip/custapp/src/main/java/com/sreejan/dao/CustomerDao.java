package com.sreejan.dao;

import com.sreejan.com.teena.model.Customer;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
public class CustomerDao {
    @PersistenceContext
    private EntityManager entityManager;

    public void addCustomer(Customer customer) {
        entityManager.persist(customer);
    }

    public Customer getCustomerByOrgNum(int orgNum) {
        return entityManager.find(Customer.class, orgNum);
    }
}
